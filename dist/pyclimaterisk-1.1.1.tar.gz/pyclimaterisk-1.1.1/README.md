This mini package provides access to latin american climate risk indices at different categoriies. Those indices are derived from a large corpus of newspapers archives and available at monthly and daily frequency. It further provides certain climate related events (laws, legistlation, presidential decrees).

The package provides three different functions. Python library `Polars` is assumed to be installed. 

```
pip install pyclimaterisk
```

```
import pyclimaterisk as cr
```

```
cr.get_monthly_data()
```

and

```
cr.get_daily_data()
```
 and 
 
```
cr.get_events_data()
```


If you use this data set, please kindly cite our work as:
- Muhsin Ciftci, and Christina Kolerus. "Climate News and Asset Valuations: Insights from Latin America", IMF Working Papers 2025, 037 (2025), https://doi.org/10.5089/9798229000932.001

